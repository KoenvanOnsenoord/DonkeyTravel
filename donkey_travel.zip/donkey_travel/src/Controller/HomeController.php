<?php

namespace App\Controller;

use App\Form\RegistrationFormType;
use App\Repository\BookingRepository;
use App\Repository\DonkeyAdventureRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Security;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;

class HomeController extends AbstractController
{
    #[Route('/', name: 'app_home')]
    public function index(): Response
    {
        return $this->render('home/index.html.twig', [
            'controller_name' => 'HomeController',
        ]);
    }

    #[Route('/login', name: 'login')]
    public function login(AuthenticationUtils $authenticationUtils): Response
    {
        // get the login error if there is one
        $error = $authenticationUtils->getLastAuthenticationError();
        // last username entered by the user
        $lastUsername = $authenticationUtils->getLastUsername();
        return $this->render('home/login.html.twig', [
            'controller_name' => 'LoginController',
            'last_username' => $lastUsername,
            'error'         => $error,
        ]);
    }


    #[Route('register', name: 'register')]
    public function register(): Response
    {

        $registrationForm = $this->createForm(RegistrationFormType::class);

        return $this->render('registration/register.html.twig', [
            'registrationForm' => $registrationForm->createView(),
        ]);

    }

    #[Route('/aboutus', name: 'aboutus')]
    public function aboutus(): Response
    {
        return $this->render('home/aboutus.html.twig', [
            'controller_name' => 'HomeController',
        ]);
    }

    #[Route('/route', name: 'route')]
    public function route(DonkeyAdventureRepository $donkeyAdventureRepository): Response
    {
        $routes=$donkeyAdventureRepository->findAll();
        //dd($routes);
        return $this->render('home/route.html.twig', [
            'donkey_adventures' => $routes,
        ]);
    }

    #[Route('/index', name: 'booking')]
    public function booking(BookingRepository $bookingRepository): Response
    {
        $booking=$bookingRepository->findAll();
        return $this->render('admin/index.html.twig', [
            'bookings' => $booking,
        ]);
    }

    #[Route('/logout', name: 'logout')]
    public function logout(): Response
    {
        // controller can be blank: it will never be called!
        throw new \Exception('Don\'t forget to activate logout in security.yaml');
    }




    #[Route('/redirect', name: 'redirect')]
    public function redirectAction(Security $security)
    {
        if ($security->isGranted('ROLE_ADMIN')) {
            return $this->redirectToRoute('app_admin');
        }
        if ($security->isGranted('ROLE_KLANT')) {
            return $this->redirectToRoute('app_klant');
        }
        return $this->redirectToRoute('app_default');
    }



}
