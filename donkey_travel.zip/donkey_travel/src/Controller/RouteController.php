<?php

namespace App\Controller;

use App\Repository\DonkeyAdventureRepository;
use App\Entity\DonkeyAdventure;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class RouteController extends AbstractController
{
    #[Route('/route', name: 'app_route')]
    public function index(): Response
    {
        return $this->render('route/index.html.twig', [
            'controller_name' => 'RouteController',
        ]);


    }

  //  #[Route('/route', name: 'app_route')]
 //   public function show(DonkeyAdventureRepository $donkeyAdventureRepository)
 //   {
//        $cat = $donkeyAdventureRepository->findAll();
  //      return $this->render('home/route.html.twig', [
   //         'cat' => $cat,
   //     ]);

  //  }
    #[Route('/route', name: 'app_route')]
    public function show(DonkeyAdventureRepository $donkeyAdventureRepository)
    {
        $donkey_adventures = $donkeyAdventureRepository->findAll();
        return $this->render('home/route.html.twig', [
            'donkey_adventures' => $donkey_adventures
        ]);


    }


}
