<?php

namespace App\Repository;

use App\Entity\DonkeyAdventure;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<DonkeyAdventure>
 *
 * @method DonkeyAdventure|null find($id, $lockMode = null, $lockVersion = null)
 * @method DonkeyAdventure|null findOneBy(array $criteria, array $orderBy = null)
 * @method DonkeyAdventure[]    findAll()
 * @method DonkeyAdventure[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class DonkeyAdventureRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, DonkeyAdventure::class);
    }

    public function save(DonkeyAdventure $entity, bool $flush = false): void
    {
        $this->getEntityManager()->persist($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    public function remove(DonkeyAdventure $entity, bool $flush = false): void
    {
        $this->getEntityManager()->remove($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

//    /**
//     * @return DonkeyAdventure[] Returns an array of DonkeyAdventure objects
//     */
//    public function findByExampleField($value): array
//    {
//        return $this->createQueryBuilder('d')
//            ->andWhere('d.exampleField = :val')
//            ->setParameter('val', $value)
//            ->orderBy('d.id', 'ASC')
//            ->setMaxResults(10)
//            ->getQuery()
//            ->getResult()
//        ;
//    }

//    public function findOneBySomeField($value): ?DonkeyAdventure
//    {
//        return $this->createQueryBuilder('d')
//            ->andWhere('d.exampleField = :val')
//            ->setParameter('val', $value)
//            ->getQuery()
//            ->getOneOrNullResult()
//        ;
//    }
}
