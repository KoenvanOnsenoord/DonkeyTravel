<?php

namespace App\Entity;

use App\Repository\OrderRowRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: OrderRowRepository::class)]
class OrderRow
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column]
    private ?int $number = null;

    #[ORM\ManyToOne(inversedBy: 'order_row')]
    private ?Order $order_property = null;

    #[ORM\ManyToOne(inversedBy: 'orderRows')]
    #[ORM\JoinColumn(nullable: false)]
    private ?product $product = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNumber(): ?int
    {
        return $this->number;
    }

    public function setNumber(int $number): self
    {
        $this->number = $number;

        return $this;
    }

    public function getOrderProperty(): ?Order
    {
        return $this->order_property;
    }

    public function setOrderProperty(?Order $order_property): self
    {
        $this->order_property = $order_property;

        return $this;
    }

    public function getProduct(): ?product
    {
        return $this->product;
    }

    public function setProduct(?product $product): self
    {
        $this->product = $product;

        return $this;
    }
}
