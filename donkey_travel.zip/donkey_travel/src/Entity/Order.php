<?php

namespace App\Entity;

use App\Repository\OrderRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: OrderRepository::class)]
#[ORM\Table(name: '`order`')]
class Order
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $betaald = null;

    #[ORM\ManyToOne(inversedBy: 'betaald')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Booking $booking = null;

    #[ORM\OneToMany(mappedBy: 'order_property', targetEntity: OrderRow::class)]
    private Collection $order_row;

    public function __construct()
    {
        $this->order_row = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getBetaald(): ?string
    {
        return $this->betaald;
    }

    public function setBetaald(string $betaald): self
    {
        $this->betaald = $betaald;

        return $this;
    }

    public function getBooking(): ?Booking
    {
        return $this->booking;
    }

    public function setBooking(?Booking $booking): self
    {
        $this->booking = $booking;

        return $this;
    }

    /**
     * @return Collection<int, OrderRow>
     */
    public function getOrderRow(): Collection
    {
        return $this->order_row;
    }

    public function addOrderRow(OrderRow $orderRow): self
    {
        if (!$this->order_row->contains($orderRow)) {
            $this->order_row->add($orderRow);
            $orderRow->setOrderProperty($this);
        }

        return $this;
    }

    public function removeOrderRow(OrderRow $orderRow): self
    {
        if ($this->order_row->removeElement($orderRow)) {
            // set the owning side to null (unless already changed)
            if ($orderRow->getOrderProperty() === $this) {
                $orderRow->setOrderProperty(null);
            }
        }

        return $this;
    }
}
