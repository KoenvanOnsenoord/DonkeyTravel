<?php

namespace App\Entity;

use App\Repository\BookingRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: BookingRepository::class)]
class Booking
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $date = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $time = null;


    #[ORM\ManyToOne(inversedBy: 'bookings')]
    #[ORM\JoinColumn(nullable: false)]
    private ?DonkeyAdventure $donkey_adventure = null;

    #[ORM\OneToMany(mappedBy: 'booking', targetEntity: Order::class)]
    private Collection $betaald;

    #[ORM\ManyToOne(inversedBy: 'Booking')]
    #[ORM\JoinColumn(nullable: false)]
    private ?User $user = null;

    public function __construct()
    {
        $this->betaald = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(\DateTimeInterface $date): self
    {
        $this->date = $date;

        return $this;
    }

    public function getTime(): ?\DateTimeInterface
    {
        return $this->time;
    }

    public function setTime(\DateTimeInterface $time): self
    {
        $this->time = $time;

        return $this;
    }

    public function getDonkeyAdventure(): ?DonkeyAdventure
    {
        return $this->donkey_adventure;
    }

    public function setDonkeyAdventure(?DonkeyAdventure $donkey_adventure): self
    {
        $this->donkey_adventure = $donkey_adventure;

        return $this;
    }

    /**
     * @return Collection<int, Order>
     */
    public function getBetaald(): Collection
    {
        return $this->betaald;
    }

    public function addBetaald(Order $betaald): self
    {
        if (!$this->betaald->contains($betaald)) {
            $this->betaald->add($betaald);
            $betaald->setBooking($this);
        }

        return $this;
    }

    public function removeBetaald(Order $betaald): self
    {
        if ($this->betaald->removeElement($betaald)) {
            // set the owning side to null (unless already changed)
            if ($betaald->getBooking() === $this) {
                $betaald->setBooking(null);
            }
        }

        return $this;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): self
    {
        $this->user = $user;

        return $this;
    }
}
