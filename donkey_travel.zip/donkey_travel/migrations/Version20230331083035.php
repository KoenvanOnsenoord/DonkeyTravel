<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20230331083035 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE order_row ADD product_id INT NOT NULL');
        $this->addSql('ALTER TABLE order_row ADD CONSTRAINT FK_C76BB9BB4584665A FOREIGN KEY (product_id) REFERENCES product (id)');
        $this->addSql('CREATE INDEX IDX_C76BB9BB4584665A ON order_row (product_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE order_row DROP FOREIGN KEY FK_C76BB9BB4584665A');
        $this->addSql('DROP INDEX IDX_C76BB9BB4584665A ON order_row');
        $this->addSql('ALTER TABLE order_row DROP product_id');
    }
}
